        <footer>
            <div class="container">
				<div class="copyright-area">
                    <div class="row">
                        <div class="col-lg-10">

                        </div>
                        <div class="col-lg-2">
                            <div class="copyright-item">
                                 2021 ® Copyrights
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.meanmenu.js"></script>
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <script src="assets/js/jquery.mixitup.min.js"></script>
        <script src="assets/js/waypoints.min.js"></script>
		<script src="assets/js/form-validator.min.js"></script>
        <script src="assets/js/contact-form-script.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/custom.js"></script>
		<script src="sub/intlTelInput.min.js"></script>
        <script src="sub/isValidNumber.js"></script>
        <script src="sub/phonelib.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.11"></script>
        <script> 
            document.onkeydown = function(e) {
                if(event.keyCode == 123) {
                    return false;
                }
                if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
                    return false;
                }
                if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
                    return false;
                }
                if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
                    return false;
                }
                if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
                    return false;
                }
            }
        </script>
    </body>
</html>